setwd("/Users/kobewhite/Documents/PCACode")


dat <- read.delim("CombinedGen_StreamData.csv", head = T, sep = ',')
head(dat)

pc <- prcomp(dat[, 6:9], scale=T, retx=T)
biplot(pc)

pc

screeplot(pc)
2.1/(2.1+1.1+0.5+0.15)
1.1/(2.1+1.1+0.5+0.15)
0.65/(2.1+1.1+0.5+0.15)

leg <- unique(cbind(dat$Stream, 20+as.numeric(as.factor(dat$Stream))))
rng <- range(round(dat[, 5], 2))
diff(rng)
pdf("pca_scatter.pdf", height = 10, width = 10, bg = "white")
plot(NULL, xlim = c(-4, 4), ylim = c(-4, 4), xlab = "PC1", ylab = "PC2", las = 1)
abline(h = 0, v = 0, lty = 3)
points(pc$x[, 1:2], bg = gray(1-(dat[, 5]-min(rng))/diff(rng)), pch=20+as.numeric(as.factor(dat$Stream)), cex=2, xlim = c(-4, 4), ylim = c(-4, 4), lwd=2, las = 1)
mult <- 3   # scaling factor, adjust until arrows look nice
arrows(0, 0,
       pc$rotation[,1]*mult,
       pc$rotation[,2]*mult,
       col = "red", length = 0.1, lwd = 1.5)

# add variable names at arrow tips
text(pc$rotation[,1]*mult*1.1,
     pc$rotation[,2]*mult*1.1,
     labels = rownames(pc$rotation),
     col = "red", cex = 0.9, font = 2)
#contour(pc$x[, 1])
 #text(pc$x[, 1], pc$x[, 2], dat$Stream, pos = 4, srt = 45, cex=0.5)
legend("topleft", leg[, 1], pch = as.numeric(leg[, 2]), pt.lwd=2, pt.bg="gray50", cex = 1.25, ncol=1, bty='n')
## colorbar - sort of

legend("topright", paste0(seq(0, 100, by=25.0), "% native"), pt.bg = gray(1-seq(0, 100, by=25.0)/100), pt.lwd=2, pch=21, cex = 1.25, ncol=1, bty='n')
dev.off()
## adds dots for means, should match styles using legend, but this probably doesn't need to be there anyway
## points(aggregate(pc$x[, 1:2], by = list(dat$Stream), mean)[, 2:3], col=2, cex=2, pch=19)


par(mfrow = c(1, 2), mar = c(4.1, 4.1, 1.1, 1.1))
boxplot(pc$x[, 1] ~ dat$Stream, xlab = "Stream", ylab = "PC 1 Scores")
boxplot(pc$x[, 2] ~ dat$Stream, xlab = "Stream", ylab = "PC 2 Scores")

# par(mfrow = c(1, 2), mar = c(4.1, 4.1, 1.1, 1.1))
# plot(dat$NeoshoBass ~ pc$x[, 1])
# mod1 <- lm(dat$NeoshoBass ~ pc$x[, 1])
# abline(mod1)

# plot(dat$NeoshoBass ~ pc$x[, 2])
# mod2 <- lm(dat$NeoshoBass ~ pc$x[, 2])
# abline(mod2)

par(mfrow = c(1, 2), mar = c(4.1, 4.1, 1.1, 1.1))
#boxplot(dat$WsAreaSqKm ~ dat$Stream)
boxplot(dat$PercentDeciduous ~ dat$Stream)

boxplot(dat$PercentHay ~ dat$Stream)
#boxplot(dat$FromResDistance ~ dat$Stream)


aggregate(pc$x[, 1:2], by = list(dat$Stream), mean)
aggregate(pc$x[, 1:2], by = list(dat$Stream), sd)
aggregate(dat$NeoshoBass, by = list(dat$Stream), mean)
aggregate(dat$NeoshoBass, by = list(dat$Stream), sd)