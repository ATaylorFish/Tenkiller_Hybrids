#####GenHapR workflow to link haplotypes to specimen data, plus haplotype visualization#####

###Housekeeping & setup
setwd("/Users/kobewhite/Documents/mtDNA_Update")
#BiocManager::install(c("geneHapR", "GenomicRanges", "IRanges", "rtracklayer"))
library(geneHapR)


###Adding sample metadata to the haplotype viz
#Importing fasta
geneSeqs <- import_seqs(filepath = "updated_SMB_mtDNA_ATrev24_12_09_noLMB.fasta", format = "fasta")

#Generating and summarizing haplotypes
geneHap <- seqs2hap(geneSeqs, pad = 2) #add position in gene and gene name
geneHap

write.csv(geneHap, file="HaplotypeTable")

#Haplotype summary table (and save this as a pdf figure)
plotHapTable(geneHap) # Note: manually save this one for nicer fit of fonts in space

pdf("HaplotypeTable_plot.pdf")
plotHapTable(geneHap)
dev.off()


###Importing sample metadata aka accession info
AccINFO <- read.csv("Sample_data_update.csv",
                    row.names = 1)
head(AccINFO)
colnames(AccINFO)


#DataViz: creating hapnet object with metadata coloring by Population (aka Ref type and wild location)
hapnet2 <- get_hapNet(geneHap,
                      AccINFO = AccINFO,           # Accession information
                      groupName = "Population", # The column name contains accession groups
                      na.label = "Unknown")        # The label for unknown individuals

plotHapNet(hapNet = hapnet2, scale = 1, show.mutation=2, pie.lim=c(.5,5), legend = c(-24.6, 15.6), cex = .1, cex.legend=.5)

plotHapNet(hapNet = hapnet2, scale = 1, show.mutation=2, pie.lim=c(.5,5), legend = FALSE, cex = .1)

unique_pops <- unique(AccINFO$Population)
legend(legend = c(unique_pops), cex = 0.5, horiz = FALSE, text.width = 0.01, bty = "n",
       c(16, 1)) # first increases height, second moves horizontal positioning of legend

pdf("HapNetPlot.pdf")
plotHapNet(hapNet = hapnet2, scale = 2.5, show.mutation=2, pie.lim=c(.5,5), legend = c(-12, 10), cex = .7, cex.legend=.8, labels.cex = 0.7)
dev.off()

pdf("HapNetPlotOld.pdf")
plotHapNet(hapNet = hapnet2, scale = 2.5, show.mutation=2, pie.lim=c(.5,5), legend = c(-12, 10), cex = .5, cex.legend=.8, labels.cex = 0.5)
dev.off()

svg("HapNetPlot.svg")
plotHapNet(
  hapNet = hapnet2,
  scale = 2.5,
  show.mutation = 2,
  pie.lim = c(0.5, 5),
  legend = c(-12, 10),
  cex = 0.7,
  cex.legend = 0.8,
  labels.cex = 0.7
)
dev.off()

###creating new hapnet object with metadata coloring by SNP_ID (i.e., Ref type or nuclear SNP ID from wild fish)
pdf("SNP.pdf")
hapnet3 <- get_hapNet(geneHap,
                      AccINFO = AccINFO,           # Accession information
                      groupName = "SNP_ID", # The column name contains accession groups
                      na.label = "Unknown")        # The label for unknown individuals
plotHapNet(hapNet = hapnet3, scale = 1, show.mutation=2, pie.lim=c(.5,5), legend = c(-12, 10), cex = .5, cex.legend=.5, labels.cex = 0.5)
dev.off()




#Major haplotype Geo-distribution
#NOTE: This needs a lot of work and may not include it 
hapMap <- hapDistribution(hap = geneHap,
                          AccINFO = AccINFO,
                          hapNames = c("H01","H02","H03"), # Haplotypes for display on the map
                          LON.col = "Long",              # The column name of Longitude
                          LAT.col = "Lat",               # The column name of Latitude
                          symbolSize = 0.9,                   # The pie size
                          lty.pie = 0,                        # Border type of pies
                          borderCol.pie = 1,                  # Border color of pies
                          lwd.pie = 1,                        # Border width of pies
                          lwd = 1,                            # Border width of countries
                          cex.legend = 1,                     # The size of legend
                          symbol.lim = c(3,6),                # The circle size
                          label.col = "black",                # The text color in circle
                          label.cex = 0.8,                    # The text size
                          label.font = 2,                     # Text font, 1 for normal and 2 for bold...
                          hap.color = c("orange","purple","violet"))# Colors of each haplotype

hapMap


