###Andrew Taylor, 8/20/2021 based on example codes - WORKS ON MACBOOK ONLY
###see:https://github.com/bwringe/hybriddetective/blob/master/README.Rmd
###See: https://github.com/bwringe/hybriddetective/blob/master/hybriddetective_example_RScript.pdf 
###Trying hybriddetective from their example code to ensure all works on local machine
###Installed NewHybrids, PLINK, and PGDspider to local machine first in "software" folder


library(genepopedit)
library(parallelnewhybrid)
library(genepopedit)
library(hybriddetective)

#######################
####PREPARE DATA FOR INPUT####

###view the example data provided
###PurePops* | A *GENEPOP* format file containing SNP genotypes of 150 individuals in each of two populations at 100 loci. To use this example data it must first be saved with the extension ".txt" to an empty folder on your hard drive.
###*PurePops_Zeds* | A data frame of known genotype category assignments (Zeds) and the indviduals to which to match them in the *NewHybrids* format files created in the examples. Refer to Anderson 2002 and the function *nh_zcore* for more information.

#data(PurePops)
#data(PurePops_Zeds)

###set working directory, hold it to add folders to later...
#not needed - setwd("/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study")
path.hold <-getwd()
## Get the genotype file included along with the hybriddetective package and make it an object
#install.packages("readtext")
#library(readtext)
#sim_PurePops <- readtext("./InputData/Tenkiller_ref_for_hybriddetective.txt")
## Get the Zeds data file included along with the hybriddetective package and make it an object
#sim_Zeds <- readtext("./InputData/Tenkiller_ref_Zeds.txt")


## Save the genotype data to the working directory as a file called "SimPurePops.txt"
#write.table(x = sim_PurePops, file = paste0(path.hold, "/SimPurePops.txt"), row.names = FALSE, col.names = FALSE, quote = FALSE)
## Save the Zeds data to the working directory as a file called "SimZeds.txt"
#write.table(x = sim_Zeds, file = paste0(path.hold, "/SimZeds.txt"), row.names = FALSE, col.names = TRUE, quote = FALSE)
## Create an empty folder within the working directory. This will be the directory for all examples.
#dir.create(paste0(path.hold, "/Tenkiller"))
## Copy the genotype file to the new folder
#file.copy(from = paste0(path.hold, "/SimPurePops.txt"), to = paste0(path.hold, "/Tenkiller"))
## Copy the Zeds data file to the new folder
#file.copy(from = paste0(path.hold, "/SimZeds.txt"), to = paste0(path.hold, "/Tenkiller"))
## Clean up the working directory by deleting the two files
#file.remove(paste0(path.hold, "/SimPurePops.txt"))
#file.remove(paste0(path.hold, "/SimZeds.txt"))
## NOTE: You must recall the file path to the hybriddetective example folder you created to use in the examples below!!!
your.path = paste0(path.hold, "/Tenkiller/")


#######################
####NHBUILD Example####

##This function will write and delete the provided pre-analyzed data that can be used to explore the use 
##and results of the functions *nh_preCheckR*, *nh_multiplotR*, and *hybridPowerComp*. 
##This function also demonstrates the manner/format in which [parallelnewhybrid](https://github.com/bwringe/parallelnewhybrid) exports the results of *NewHybrids* analyses. 
##The function will write the example data to a folder/file path specified by the user.

## INSTALL EXAMPLE DATA
## Get the file path to the working directory, will be used to allow a universal example
path.hold <- getwd()
## Note: the path provided must end in '/' 
nh_build_example_results(dir = paste0(path.hold, "/")) # this will write the example data to the working directory
###If this throws errors, need to delete/move previous NewHybrids results from directory
## To remove the EXAMPLE DATA
#nh_build_example_results(dir = paste0(path.hold, "/"), remove_example = TRUE)

#######################
####GET TOP LOCI####
####There's no need to do this part for our msat data!!!

##This function is designed to produce panels of the *n* loci not in linkage disequilibrium with 
##the highest loci-specific Fst, where *n* is a number specified by the user. 
##The data provided to the function are broken into two data sets, one to be used to calculate 
##the loci-specific Fsts, and the other to be used to created simulated hybrid datasets to test 
##the efficacy of the panel. This is done to prevent high-grading bias where the same data is 
##used to develop the panel(s) that is then used in their validation (Anderson 2010). 

##The function will save three files to the folder that contains the data provided. 

##The first file is a list of the top *n* loci, ordered by Fst, which can be used to subset data in 
##with the function **genepop_subset** from the **genepopedit** package. 

##The second file is a list of the individuals from each of the two populations that were subsetted out to form the testing panel. 

##The final file are the genotypes of the individuals listed in the second file, at the top *n* loci not in linkage disequilibrium (listed in the first file). 

##This dataset can be used in the **freqbasedsim** functions to create simulated hybrids for panel efficacy testing. 

##NOTES:
##Data must be entered into the function as a two-population GENEPOP format file.  
##The programs **PLINK** and **PGDspider** are required to run **getTopLoc.R**. Refer to package installation for downloading instructions.  

##INITIATING EXAMPLE
##To create a panel consisting of the top 50 Loci from the example dataset *PurePops* (Note: There are only 100 loci total in the example data, so the requested panel size may not exceed 100)
## There is no need with the example dataset to alter any function parameters apart from providing the required file paths and the desired panel size
## recall the filepath to the hybriddetective example folder
path.hold <- getwd()
#your_example_data_path = paste0(path.hold, "/Tenkiller/Tenkiller_ref_for_hybriddetective_copy.txt")
### assume PGDSpider and PLINK are both installed in a folder called "software"
#your_plink_path = "/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/software/plink_mac_20210606/"
#your_pgdspider_path = "/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/software/PGDSpider_2.1.1.5/"
#toploc <- getTopLoc(GPD = your_example_data_path, panel.size = 8, where.PLINK = your_plink_path, where.PGDspider = your_pgdspider_path)
### This will create a file containing the 50 loci with the greatest Fst values, that are not in LD above an r^2 of 0.2. 
### Note: The file "SimPurePops_50_Loci_Panel.txt" is the file to be used for the simulations

###getTopLoc throws error message in Windows, see:https://github.com/bwringe/hybriddetective/issues/5
###YAY, this seems to be working on my Macbook 7/28/2021

#######################
####SIMULATED HYBRIDS FROM REF POPS####
## Here I am simulating genotypes for 6 hybrid categories using the top loci discovered in the PLINK validation samples for each parent dataset. 
## The freqbasedsim_AlleleSample() function generates a number of individuals in each hybrid category based on allele frequencies in references

## Genotypes were simulated 3 separate times (S1, S2, S3), and for each set of simulations (unique genotype datasest), 
##I performed 3 replicate hybrid generation simulations (R1, R2, R3). 
##This way, I can assess deviations across simulations (S) AND within simulations (R).

##Make sure to read in the file created from getTopLoc function
##*outputName*| An optional character vector to be applied as the name of the output. 
####The default is NULL, in which case the output name is constructed from the name of the input, 
##with the *suffix _SiRj_NH* added where *i* is the number of simulations corresponding to the output, 
##and *j* is the number of replicates of the *ith* simulation. 
##NH refers to the fact that the output is in NewHybrids format 
##default sample size is 200 individuals per sim

#freqbasedsim_GTFreq(GenePopData ="/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/Tenkiller/Tenkiller_ref_for_hybriddetective_copy.txt", 
                    #NumSims = 1, 
                    #NumReps = 3)

freqbasedsim_AlleleSample(GPD ="/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/Tenkiller/Tenkiller_ref_for_hybriddetective_copy.txt", 
                          NumSims = 3, 
                          NumReps = 3)
#sample.sizePure1 = 200,
#sample.sizePure2 = 200,
#sample.sizeF1 = 200,
#sample.sizeF2 = 200,
#sample.sizeBC1 = 200,
#sample.sizeBC2 = 200)

###Run Simulated hybrids with parallelnewhybrids to assign simulated genotypes to hybrid class 
###(Bayesian Gibbs sampling algorithm). 
###NewHybrids was installed on my local machine (MAC OS) to conduct the analysis
###Be sure to record final burnin and sweeps for methods

###NOTE: had to install newhybrids from Git, then XCode app was needed to compile and run on local machine successfully

##This line of code runs but, best to clear out all other input files besides those from the simulated pops plus the pure individuals
##before executing this line of code, otherwise flags SimPurePops.txt and SimZeds.txt for improper format.  It is okay to ignore.

parallelnh_OSX("/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/Tenkiller/", 
               where.NH = "/Users/andrewtaylor/newhybrids/", 
               burnin = 500000, 
               sweeps = 1000000)

###with Tenkiller dataset, would MCMC would not converge on Hooch vs Bama with 500,000 and 1,000,000 reps
###Trying with 2 mil sweeps, starting with just one sim to test it
###also didn't converge
###will try different sampling strategy for simulated refs...

## precheckR will check for NewHybrids results in all folders within the folder specified by "PreDir". i.e. all results in the folders within the "NH.Results" folder created by parallelnh_xx from the package parallelnewhybrid
##NOTE: before running this, remove from NH.Results folder 3 subfolders "..Panel.txt", "SimPurePops.txt", and "SimZeds.txt" _Results
nh_preCheckR(PreDir="/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/Tenkiller/NH.Temp/", propCutOff = 0.5, PofZCutOff = 0.1)
## run with the default cut-off values; these could have been left blank.
### preCheckR will now flag any results where more than 50% (propCutOFF) of EITHER Pure1 or Pure2 individuals are given a probability of being an F2 greater than 10% (PofZCutOff)

##Plot the results so far..."structure plot" style
##order should be mostly pure 1, pure 2, F1, F2, BC1, BC2...otherwise it may show failure to converge
nh_multiplotR(NHResults="/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/Tenkiller/NH.Results/")

#################
####Evaluate the hybrid-class specific efficacy of the panel across a range of
####posterior probability of assignment thresholds

###Note, if this command is used with only one panel size, it will issue a "geom_path" warning that can be ignored
###Creates 31 plots "Plot_1" thru Plot_31 (see ReadME), saves them all as tables, too with .csv files
hybridPowerComp(dir="/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/Tenkiller/NH.Results/")


###########
#####Combine the experimental (unknown) genotypes with the simulated pure genotypes
nh_analysis_generateR(
  ReferencePopsData = "/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/Tenkiller/Tenkiller_ref_for_hybriddetective_copy_S1R1_NH.txt",
  UnknownIndivs = "/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/Tenkiller/inputs/Tenkiller_wild_for_hybriddetective.txt",
  output.name = "NH_Tenkiller_assignments_final_output.txt")

###Take the resulting two files and save them in a subfolder of NH.Results called "Combined"
###Make the zscore file mannually from the individuals file

###Optional step to add Zeds (known hybrid class designations) from .csv file to simulated individuals
###Can help NewHybrids more accurately model the expected genotypes of potential mixtures of two parentals
#z indicates that it is known beforehand the hybrid class of an individual
#0 indicates pure for pop 1, 1 indicates pure for pop 2
#s indicates the individual is to be used for calc of allele freqs only
#For more info, see NewHybrids User Guide
#nh_Zcore(GetstheZdir = "/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/hybriddetective example/",
        # multiapplyZvec = "/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/hybriddetective example/EXAMPLEZEDS.csv")

###Run NewHybrids on the combined data
parallelnh_OSX("/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/Tenkiller/NH.Results/Combined/", 
               where.NH = "/Users/andrewtaylor/newhybrids/", 
               burnin = 500000, 
               sweeps = 1000000)

###Move resulting NH.Results folder to the "Combined" parent folder

###Visualize results
###First shows pure 1 (blue) and pure 2 (red) from simulated pops, then unknown individuals
nh_plotR("/Users/andrewtaylor/Desktop/R_Projects/R_impound_study/R_impound_study/Tenkiller/NH.Results/Combined/NH_Tenkiller_assignments_final_output.txt_Results/NH_Tenkiller_assignments_final_output.txt_PofZ.txt")
