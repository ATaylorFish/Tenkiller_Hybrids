setwd("/Users/kobewhite/Desktop/SMB_Data/Hybriddetective")

#devtools::install_github("bwringe/parallelnewhybrid") #required
#devtools::install_github("rystanley/genepopedit") #required
#devtools::install_github("bwringe/hybriddetective") #This package


library(devtools)
library(genepopedit)
library(parallelnewhybrid)
library(hybriddetective)
library(adegenet)


####PREPARE DATA FOR INPUT####

###set working directory, hold it to add folders to later...
path.hold <-getwd()



#Make a combined input file for newhybrids
#this works
nh_analysis_generateR(
  ReferencePopsData = "/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/genpopref_editspace_v2.txt",
  UnknownIndivs = "/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/genpopwild_editspace_v2.txt",
  output.name = "OUTPUT_editspace.txt")

#Add the two OUTPUT files to a folder named "Combined"

###Run NewHybrids on the combined data
parallelnh_OSX("/Users/kobewhite/Desktop/SMB_Data/Hybriddetective/Combined/", 
               where.NH = "/Users/kobewhite/Desktop/Hybriddetective/newhybrids/", 
               burnin = 500, 
               sweeps = 100000)

#check for convergence
nh_preCheckR(PreDir="/Users/kobewhite/Desktop/SMB_Data/Hybriddetective/Combined/NH.Results/", propCutOff = 0.5, PofZCutOff = 0.1)

###Visualize results
###First shows pure 1 (blue) and pure 2 (red) from simulated pops, then unknown individuals
nh_plotR("/Users/kobewhite/Desktop/SMB_Data/Hybriddetective/Combined/NH.Results/OUTPUT_editspace.txt_Results/OUTPUT_editspace.txt_PofZ.txt")

nh_multiplotR(NHResults = "/Users/kobewhite/Desktop/SMB_Data/Hybriddetective/Combined/NH.Results/")


### create reference populations comprised of 50 individuals. 
#Make 3 independent simulations, and 3 replicates of each.
nh_analysis_simulateR_generateR(ReferencePopsData = "genpopref_editspace_v2.txt"
                                , UnknownIndvs = "genpopwild_editspace_v2.txt", 
                                sample.size = 50, NumSims = 3, NumReps = 3) 








freqbasedsim_AlleleSample(GPD = "/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/Tenkiller_ref_for_hybriddetective_copy.txt", 
                          NumSims = 3, 
                          NumReps = 3)

#Make a combined input file for newhybrids
#this works
nh_analysis_generateR(
  ReferencePopsData = "/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/ref_combsmsp_19_21.txt",
  UnknownIndivs = "/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/wildpop_combsmsp_19_21.txt",
  output.name = "OUTPUT_editspacesmsp.txt")

#Add the two OUTPUT files to a folder named "Combined"

###Run NewHybrids on the combined data
parallelnh_OSX("/Users/kobewhite/Desktop/SMB_Data/Hybriddetective/Combined/", 
               where.NH = "/Users/kobewhite/Desktop/Hybriddetective/newhybrids/", 
               burnin = 500, 
               sweeps = 100000)

#check for convergence
nh_preCheckR(PreDir="/Users/kobewhite/Desktop/SMB_Data/Hybriddetective/Combined/NH.Results/", propCutOff = 0.5, PofZCutOff = 0.1)

###Visualize results
###First shows pure 1 (blue) and pure 2 (red) from simulated pops, then unknown individuals
nh_plotR("/Users/kobewhite/Desktop/SMB_Data/Hybriddetective/Combined/NH.Results/OUTPUT_editspace.txt_Results/OUTPUT_editspace.txt_PofZ.txt")

nh_multiplotR(NHResults = "/Users/kobewhite/Desktop/SMB_Data/Hybriddetective/Combined/NH.Results/")


### create reference populations comprised of 50 individuals. 
#Make 3 independent simulations, and 3 replicates of each. 
##pop a =SMB pop b = SPB
nh_analysis_simulateR_generateR(ReferencePopsData = "ref_combsmsp_19_21.txt"
                                , UnknownIndvs = "wildpop_combsmsp_19_21.txt", 
                                sample.size = 50, NumSims = 3, NumReps = 3) 









##Runnig NewHybs for 2019-2021 N_SM SNP Panel
setwd("/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective")

getwd()

#library(devtools)
library(genepopedit)
library(parallelnewhybrid)
library(hybriddetective)
#library(adegenet)


####PREPARE DATA FOR INPUT####

###set working directory, hold it to add folders to later...
path.hold <-getwd()

freqbasedsim_GTFreq(GenePopData ="/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/genpopref_editspace_v2_ATT.txt", 
                    NumSims = 3, 
                    NumReps = 3, sample.sizePure = 50, sample.sizeF1 = 50,
                    sample.sizeF2 = 50,
                    sample.sizeBC = 50,
                    pop.groups = c("NEO", "SMB"))

freqbasedsim_AlleleSample(GPD = "/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/genpopref_editspace_v2_ATT.txt", 
                          NumSims = 3, 
                          NumReps = 3)

#Make a combined input file for newhybrids
#this works
nh_analysis_generateR(
  ReferencePopsData = "/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/refcombnsm_19_21.txt",
  UnknownIndivs = "/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/wildpopcombnsm_19_21.txt",
  output.name = "OUTPUT_editspacensm.txt")









##Formatting and old code:

x <- read.structure("2019_Structure_popIDedit3.stru", n.ind = 691, n.loc = 28, onerowperind = TRUE,
                    col.lab = 1, col.pop = 3,col.others = 2, NA.char = "-9", ask = TRUE, quiet = TRUE)


###examine genind object for accuracy and completeness
is.genind(x)
summary(x)

xpop <- genind2genpop( x) #pop = NULL, quiet = FALSE, process.other = FALSE,other.action = mean)
summary(xpop)
head(xpop)

xdf <- genind2df(x, oneColPerAll = FALSE, sep="/")
summary(xdf)
head(xdf)

#split populations; create a file of reference individuals (NEO(pop1) and SMB(pop2))
xdf.ref <- xdf[substr(xdf$pop, 1, 3) =="ref", ]
##export as tenkillerwildforhybriddetective txt format
write.table(xdf, "genind2df.csv", col.names=TRUE, row.names=TRUE, sep=",")

writeGenPop(x, file.name = "genpopref.txt", comment = "ref NEO vs ref SMB")
#file.remove("test.gen")
