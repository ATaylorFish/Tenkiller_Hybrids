#Hybriddetective try for Kobe's SMB SNP data on Dr. Taylor's macbook
###NSM side of panel

library(genepopedit)
library(parallelnewhybrid)
library(hybriddetective)


####PREPARE DATA FOR INPUT####

###set working directory, hold it to add folders to later...
setwd("/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/")
path.hold <-getwd()

###NOTE: These two commands below should automate this process but they throw errors, can't figure out why.
#nh_analysis_simulateR_generateR(ReferencePopsData = "ref_combsmsp_19_21edit_v2.txt", UnknownIndvs = "wildpop_combsmsp_19_21edit_v2.txt")
#nh_analysis_generateR(ReferencePopsData = "ref_combsmsp_19_21edit_v2.txt", UnknownIndivs = "wildpop_combsmsp_19_21edit_v2.txt")
###Onward without these functions!!!


####SIMULATED HYBRIDS FROM REF POPS####
#Three different simulations, 1 rep each with 300 simulated fish genotypes created in each
#Named with _SxRx_NH convention at end of file names that are created, which we will track below

freqbasedsim_GTFreq(GenePopData ="/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/ref_combnsm_19_21_edit.txt",
                    NumSims = 3,
                    NumReps = 1,
                    sample.sizePure = 50,
                    sample.sizeF1 = 50,
                    sample.sizeF2 = 50,
                    sample.sizeBC = 50,
                    pop.groups = c("Neosho", "Smallmouth"))



###########COMBINE SIMULATED GENOTYPES WITH UNKNOWN WILD GENOTYPES#########
#####Combine the experimental (unknown) genotypes with the simulated hybrid class genotypes created above
####Note, this step will take only the pure parentals (n=50 of each) of each simulated set to use as references in Newhybrids
nh_analysis_generateR(
  ReferencePopsData = "/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/ref_combnsm_19_21_edit_S1R1_NH.txt",
  UnknownIndivs = "/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/wildpop_combnsm_19_21_edit.txt",
  output.name = "combnsm_19_21_S1R1_NH.txt")

###IMPORTANT: Manually Take the resulting two files and save them in a subfolder of NH.Results called "Combined_SxRx_NH" after each run

###Now doing this same step for the other two simulations
nh_analysis_generateR(
  ReferencePopsData = "/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/ref_combnsm_19_21_edit_S2R1_NH.txt",
  UnknownIndivs = "/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/wildpop_combnsm_19_21_edit.txt",
  output.name = "combnsm_19_21_S2R1_NH.txt")

nh_analysis_generateR(
  ReferencePopsData = "/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/ref_combnsm_19_21_edit_S3R1_NH.txt",
  UnknownIndivs = "/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/wildpop_combnsm_19_21_edit.txt",
  output.name = "combnsm_19_21_S3R1_NH.txt")

####RUNNING NEWHYBRIDS#####
###Run NewHybrids on the combined data for each of the three simulations from the folder each Sim is saved in
parallelnh_OSX("/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S1R1_NH/", 
               where.NH = "/Users/andrewtaylor/newhybrids/", 
               burnin = 500000, 
               sweeps = 1000000)

parallelnh_OSX("/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S2R1_NH/", 
               where.NH = "/Users/andrewtaylor/newhybrids/", 
               burnin = 500000, 
               sweeps = 1000000)

parallelnh_OSX("/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S3R1_NH/", 
               where.NH = "/Users/andrewtaylor/newhybrids/", 
               burnin = 500000, 
               sweeps = 1000000)

#After runs are complete and stored in NH.Results folders, check for convergence of each 
nh_preCheckR(PreDir="/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S1R1_NH/NH.Results/", propCutOff = 0.5, PofZCutOff = 0.1)

nh_preCheckR(PreDir="/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S2R1_NH/NH.Results/", propCutOff = 0.5, PofZCutOff = 0.1)

nh_preCheckR(PreDir="/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S3R1_NH/NH.Results/", propCutOff = 0.5, PofZCutOff = 0.1)


####NEEDS WORK BELOW
###Visualize results
###First shows pure 1 (blue) and pure 2 (red) from simulated pops, then unknown individuals
###Plotting both ways so plot can be saved with colors that match original simulations for the system
nh_plotR("/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S1R1_NH/NH.Results/combnsm_19_21_S1R1_NH.txt_Results/combnsm_19_21_S1R1_NH.txt_PofZ.txt", ReversePure = 1)
nh_plotR("/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S1R1_NH/NH.Results/combnsm_19_21_S1R1_NH.txt_Results/combnsm_19_21_S1R1_NH.txt_PofZ.txt", ReversePure = 2)

nh_plotR("/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S2R1_NH/NH.Results/combnsm_19_21_S2R1_NH.txt_Results/combnsm_19_21_S2R1_NH.txt_PofZ.txt", ReversePure = 1)
nh_plotR("/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S2R1_NH/NH.Results/combnsm_19_21_S2R1_NH.txt_Results/combnsm_19_21_S2R1_NH.txt_PofZ.txt", ReversePure = 2)

nh_plotR("/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S3R1_NH/NH.Results/combnsm_19_21_S3R1_NH.txt_Results/combnsm_19_21_S3R1_NH.txt_PofZ.txt", ReversePure = 1)
nh_plotR("/Users/andrewtaylor/Desktop/R_Projects/R_Kobe_SMB2/Combined_S3R1_NH/NH.Results/combnsm_19_21_S3R1_NH.txt_Results/combnsm_19_21_S3R1_NH.txt_PofZ.txt", ReversePure = 2)
#Manually save as desired, e.g., jpeg 300 dpi and pdf


###Lastly, will need to compare the assignments for wild fish across the three sims using the PofZ.txt files.  
###Likely could use an average PofZ for final assignment across the three simulations to a final hybrid class

