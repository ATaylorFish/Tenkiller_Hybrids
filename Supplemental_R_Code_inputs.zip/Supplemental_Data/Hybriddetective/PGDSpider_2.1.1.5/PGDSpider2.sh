﻿#!/bin/sh

java -Xmx1024m -Xms512m -jar PGDSpider2.jar
