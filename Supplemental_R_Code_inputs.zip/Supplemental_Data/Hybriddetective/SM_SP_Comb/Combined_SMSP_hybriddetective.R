##Runnig NewHybs for 2019-2021 SMSP SNP Panel
setwd("/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/SM_SP_Comb")

getwd()

#library(devtools)
library(genepopedit)
library(parallelnewhybrid)
library(hybriddetective)
#library(adegenet)


####PREPARE DATA FOR INPUT####

###set working directory, hold it to add folders to later...
path.hold <-getwd()

freqbasedsim_GTFreq(GenePopData ="/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/SM_SP_Comb/ref_combsmsp_19_21edit_v2.txt", 
                    NumSims = 3, 
                    NumReps = 3, sample.sizePure = 50, sample.sizeF1 = 50,
                    sample.sizeF2 = 50,
                    sample.sizeBC = 50,
                    pop.groups = c("SMB", "SPB"))

freqbasedsim_AlleleSample(GPD = "/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/SM_SP_Comb/ref_combsmsp_19_21edit_v2.txt", 
                          NumSims = 3, 
                          NumReps = 3)
