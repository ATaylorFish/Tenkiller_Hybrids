setwd("/Users/kobewhite/Desktop/SMB_Data/Hybriddetective/Genepopedit")

ref <- read.delim("genpopref_v2.txt", header=F, sep=' ')
for(i in 1:ncol(ref[, -1])) {
  ref[, -1][i][ref[, -1][i]==0] <- "000000"
  ref[, -1][i][ref[, -1][i]==11] <- "001001"
	ref[, -1][i][ref[, -1][i]==22] <- "002002"
	ref[, -1][i][ref[, -1][i]==33] <- "003003"
	ref[, -1][i][ref[, -1][i]==44] <- "004004"

	ref[, -1][i][ref[, -1][i]==12] <- "001002"
	ref[, -1][i][ref[, -1][i]==13] <- "001003"
	ref[, -1][i][ref[, -1][i]==14] <- "001004"

	ref[, -1][i][ref[, -1][i]==21] <- "002001"
	ref[, -1][i][ref[, -1][i]==23] <- "002003"
	ref[, -1][i][ref[, -1][i]==24] <- "002004"

	ref[, -1][i][ref[, -1][i]==31] <- "003001"
	ref[, -1][i][ref[, -1][i]==32] <- "003002"
	ref[, -1][i][ref[, -1][i]==34] <- "003004"

	ref[, -1][i][ref[, -1][i]==41] <- "004001"
	ref[, -1][i][ref[, -1][i]==42] <- "004002"
	ref[, -1][i][ref[, -1][i]==43] <- "004003"



}

write.table(ref, "genpopref_edit.txt", col.names=F, row.names=F, sep=' ')


wild <- read.delim("genpopwild_v2.txt", header=F, sep=' ')
for(i in 1:ncol(wild[, -1])){
	wild[, -1][i][wild[, -1][i]==11] <- "001001"
	wild[, -1][i][wild[, -1][i]==22] <- "002002"
	wild[, -1][i][wild[, -1][i]==33] <- "003003"
	wild[, -1][i][wild[, -1][i]==44] <- "004004"

	wild[, -1][i][wild[, -1][i]==12] <- "001002"
	wild[, -1][i][wild[, -1][i]==13] <- "001003"
	wild[, -1][i][wild[, -1][i]==14] <- "001004"

	wild[, -1][i][wild[, -1][i]==21] <- "002001"
	wild[, -1][i][wild[, -1][i]==23] <- "002003"
	wild[, -1][i][wild[, -1][i]==24] <- "002004"

	wild[, -1][i][wild[, -1][i]==31] <- "003001"
	wild[, -1][i][wild[, -1][i]==32] <- "003002"
	wild[, -1][i][wild[, -1][i]==34] <- "003004"

	wild[, -1][i][wild[, -1][i]==41] <- "004001"
	wild[, -1][i][wild[, -1][i]==42] <- "004002"
	wild[, -1][i][wild[, -1][i]==43] <- "004003"

	wild[, -1][i][wild[, -1][i]==00] <- "000000"

}

write.table(wild, "genpowild_edit.txt", col.names=F, row.names=F, sep=' ')


## delete quotation marks, delete any NAs on 'pop' rows
## paste into file with header name


##Doing this for 2019-2021 SMSP SNP Panel
setwd("/Users/kobewhite/Library/CloudStorage/GoogleDrive-smbproject2123@gmail.com/My Drive/SMBproject/SMB_GitHub/Hybriddetective/Genepopedit/CombinedSMSP_SNPs")
library(adegenet)  #readstructure command to genind 
library(dplyr)  # data manipulation functions
library(genepopedit)


x <- read.structure("combsmsp_19_21_edit.stru", n.ind = 1345, n.loc = 18, onerowperind = TRUE,
                    col.lab = 1, col.pop = 3,col.others = 2, NA.char = "-9", ask = TRUE, quiet = TRUE)

###examine genind object for accuracy and completeness
is.genind(x)
summary(x)

xpop <- genind2genpop( x) #pop = NULL, quiet = FALSE, process.other = FALSE,other.action = mean)
summary(xpop)
head(xpop)

xdf <- genind2df(x, oneColPerAll = FALSE, sep=":")
summary(xdf)
head(xdf)

#split populations; create a file of reference individuals (SM(pop1) and SP(pop2))
xdf.ref <- xdf[substr(xdf$pop, 1, 3) =="ref", ]
##export as tenkillerwildforhybriddetective txt format
write.table(xdf, "genind2df.csv", col.names=TRUE, row.names=TRUE, sep=",")

writeGenPop(x, file.name = "genpopref.txt", comment = "ref SM vs ref SP")
#file.remove("test.gen")





wild <- read.delim("wildpop_combsmsp_19_21.csv", header=F, sep=' ')
for(i in 1:ncol(wild[, -1])){
  wild[, -1][i][wild[, -1][i]==11] <- "001001"
  wild[, -1][i][wild[, -1][i]==22] <- "002002"
  wild[, -1][i][wild[, -1][i]==33] <- "003003"
  wild[, -1][i][wild[, -1][i]==44] <- "004004"
  
  wild[, -1][i][wild[, -1][i]==12] <- "001002"
  wild[, -1][i][wild[, -1][i]==13] <- "001003"
  wild[, -1][i][wild[, -1][i]==14] <- "001004"
  
  wild[, -1][i][wild[, -1][i]==21] <- "002001"
  wild[, -1][i][wild[, -1][i]==23] <- "002003"
  wild[, -1][i][wild[, -1][i]==24] <- "002004"
  
  wild[, -1][i][wild[, -1][i]==31] <- "003001"
  wild[, -1][i][wild[, -1][i]==32] <- "003002"
  wild[, -1][i][wild[, -1][i]==34] <- "003004"
  
  wild[, -1][i][wild[, -1][i]==41] <- "004001"
  wild[, -1][i][wild[, -1][i]==42] <- "004002"
  wild[, -1][i][wild[, -1][i]==43] <- "004003"
  
  wild[, -1][i][wild[, -1][i]==-9:-9] <- "000000"
  
}

write.table(wild, "genpowild_edit.txt", col.names=F, row.names=F, sep=' ')