setwd("/Users/kobewhite/Desktop/SMB_Data/Hybriddetective/Genepopedit")

ref <- read.delim("genpopref_v2nohead.txt", header=F, sep=' ')
for(i in 1:ncol(ref[, -1])){
	
	ref[, -1][i][ref[, -1][i]==0] <- "000000"
	
	ref[, -1][i][ref[, -1][i]==11] <- "001001"
	ref[, -1][i][ref[, -1][i]==22] <- "002002"
	ref[, -1][i][ref[, -1][i]==33] <- "003003"
	ref[, -1][i][ref[, -1][i]==44] <- "004004"

	ref[, -1][i][ref[, -1][i]==12] <- "001002"
	ref[, -1][i][ref[, -1][i]==13] <- "001003"
	ref[, -1][i][ref[, -1][i]==14] <- "001004"

	ref[, -1][i][ref[, -1][i]==21] <- "002001"
	ref[, -1][i][ref[, -1][i]==23] <- "002003"
	ref[, -1][i][ref[, -1][i]==24] <- "002004"

	ref[, -1][i][ref[, -1][i]==31] <- "003001"
	ref[, -1][i][ref[, -1][i]==32] <- "003002"
	ref[, -1][i][ref[, -1][i]==34] <- "003004"

	ref[, -1][i][ref[, -1][i]==41] <- "004001"
	ref[, -1][i][ref[, -1][i]==42] <- "004002"
	ref[, -1][i][ref[, -1][i]==43] <- "004003"

}

write.table(ref, "genpopref_editspace.txt", col.names=F, row.names=F, sep=' ', quote=F)
## delete NA row from second pop line, largely unavoidable
## paste in heading

wild <- read.delim("genpopwild_v2.txt", header=F, sep=' ')
for(i in 1:ncol(wild[, -1])){
	
	wild[, -1][i][wild[, -1][i]==0] <- "000000"
	
	wild[, -1][i][wild[, -1][i]==11] <- "001001"
	wild[, -1][i][wild[, -1][i]==22] <- "002002"
	wild[, -1][i][wild[, -1][i]==33] <- "003003"
	wild[, -1][i][wild[, -1][i]==44] <- "004004"

	wild[, -1][i][wild[, -1][i]==12] <- "001002"
	wild[, -1][i][wild[, -1][i]==13] <- "001003"
	wild[, -1][i][wild[, -1][i]==14] <- "001004"

	wild[, -1][i][wild[, -1][i]==21] <- "002001"
	wild[, -1][i][wild[, -1][i]==23] <- "002003"
	wild[, -1][i][wild[, -1][i]==24] <- "002004"

	wild[, -1][i][wild[, -1][i]==31] <- "003001"
	wild[, -1][i][wild[, -1][i]==32] <- "003002"
	wild[, -1][i][wild[, -1][i]==34] <- "003004"

	wild[, -1][i][wild[, -1][i]==41] <- "004001"
	wild[, -1][i][wild[, -1][i]==42] <- "004002"
	wild[, -1][i][wild[, -1][i]==43] <- "004003"


}

write.table(wild, "genpowild_editspace.txt", col.names=F, row.names=F, sep=' ', quote=F)


## delete NA row from second pop line, largely unavoidable
## paste in heading