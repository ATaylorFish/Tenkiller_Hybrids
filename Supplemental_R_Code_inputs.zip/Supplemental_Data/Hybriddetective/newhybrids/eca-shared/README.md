Some code that is shared between my projects.  This will get pulled in as a submodule.
