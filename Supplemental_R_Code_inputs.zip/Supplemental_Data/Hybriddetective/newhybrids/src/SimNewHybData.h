/*
	Prototypes for the SimNewHybData.c  routines
*/ 





